package com.example.snapcam;

import android.app.Activity;
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private val cameraUrl = "http://192.168.4.1/capture"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        captureButton.setOnClickListener {
            DownloadImageTask().execute(cameraUrl)
        }
    }

    private inner class DownloadImageTask : AsyncTask<String, Void, ByteArray?>() {
        override fun doInBackground(vararg urls: String): ByteArray? {
        return try {
            val url = URL(urls[0])
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connect()

            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val inputStream: InputStream = connection.inputStream
                return inputStream.readBytes()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e("Snapcam", "Error al descargar la imagen: ${e.message}")
            null
        }
        }

        override fun onPostExecute(result: ByteArray?) {
            result?.let {
                // Guardar la imagen en el almacenamiento
                saveImageToStorage(it)
            }
        }
    }

    private fun saveImageToStorage(imageData: ByteArray) {
        val imageFile = File(getExternalFilesDir(null), "captured_image.jpg")
        try {
            val outputStream: OutputStream = FileOutputStream(imageFile)
            outputStream.write(imageData)
            outputStream.close()
            Log.d("Snapcam", "Imagen guardada en: ${imageFile.absolutePath}")
        } catch (e: IOException) {
            Log.e("Snapcam", "Error al guardar la imagen: ${e.message}")
        }
    }
}
3. activity_main.xml
Asegúrate de que la interfaz de usuario tenga un botón para capturar la imagen.

xml
Copiar código
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
android:layout_width="match_parent"
android:layout_height="match_parent"
android:gravity="center"
android:orientation="vertical">

    <Button
android:id="@+id/captureButton"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:text="Capturar Imagen" />
</LinearLayout>

public class MainActivity extends Activity {
}
